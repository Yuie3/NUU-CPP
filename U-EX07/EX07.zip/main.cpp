#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

struct stu {
    int num;
    string name;
    int score[7];
    // cs, jg, kj, jj, wjv, xccj(avg), rank;
    //  0,  1,  2,  3,   4,         5,    6;
};

void gen_class(stu *, int);
void num_sort(stu *, int);
void avg_sort(stu *, int);
void score_sort(stu *, int, char);
void search_stu(stu*, int);
void print_all(stu*, int);

int main() {

    int clanum;
    cout<< "�п�J���Z�H��: ";
    cin >>clanum;
    stu cla[clanum];
    gen_class(cla, clanum);

    char menu = ' ';
    while(menu != 'B') {
        cout<< "1. ���ͥ��Z���(�@�}�l�N���ͦn�F�ҥH�A���F�]�S��)\n"
            << "2. �̾Ǹ��Ƨ�(�O�o��ܥ��Z���Z)\n"
            << "3. �̾Ǵ����Z�Ƨ�(�O�o��ܥ��Z���Z)\n"    // 6 & 5
            << "4. �̵{�]���Z�Ƨ�(�O�o��ܥ��Z���Z)\n"    // 0
            << "5. �̭p�����Z�Ƨ�(�O�o��ܥ��Z���Z)\n"    // 1
            << "6. �̷|�p���Z�Ƨ�(�O�o��ܥ��Z���Z)\n"    // 2
            << "7. �̸g�٦��Z�Ƨ�(�O�o��ܥ��Z���Z)\n"    // 3
            << "8. �̷L�n�����Z�Ƨ�(�O�o��ܥ��Z���Z)\n"  // 4
            << "9. ��ܥ��Z���Z\n"
            << "A. �d�߬Y�ͦ��Z\n"
            << "B. �����{��\n"
            << "   �п�J���: ";
        cin >> menu;
        system("CLS");
        switch(menu) {
            case '1':   break;
            case '2':   num_sort(cla, clanum); break;
            case '3':   avg_sort(cla, clanum); break;
            case '4':
            case '5':
            case '6':
            case '7':
            case '8':   score_sort(cla, clanum, menu); break;
            case '9':   print_all(cla, clanum); break;
            case 'A':   search_stu(cla, clanum); break;
        }
    }
    return 0;
}

void num_sort(stu *cla, int clanum) {
    stu tmp;
    for (int i = 0; i < clanum; i++) {
        for (int j = i; j < clanum; j++) {
            if(cla[i].num > cla[j].num) {
                tmp = cla[i];
                cla[i] = cla[j];
                cla[j] = tmp;
            }
        }
    }
}

void avg_sort(stu *cla, int clanum) {
    stu tmp;
    for (int i = 0; i < clanum; i++) {
        for (int j = i; j < clanum; j++) {
            if(cla[i].score[6] < cla[j].score[6]) {
                tmp = cla[i];
                cla[i] = cla[j];
                cla[j] = tmp;
            }
        }
    }
}

void score_sort(stu *cla, int clanum, char menu) {
    stu tmp;
    int k = (int)menu - 4;
    for (int i = 0; i < clanum; i++) {
        for (int j = i; j < clanum; j++) {
            if(cla[i].score[k] < cla[j].score[k]) {
                tmp = cla[i];
                cla[i] = cla[j];
                cla[j] = tmp;
            }
        }
    }
}

void search_stu(stu *cla, int clanum) {
    int num;
    cout<< "�п�J�n�d�ߪ��Ǹ�: ";
    cin >>num;
    for (int i = 0; i < clanum; i++) {
        if(cla[i].num == num) {
            cout<< "�Ǹ�: "<< cla[i].num
                << "\t�m�W: "<< cla[i].name
                << "\n�{�]: "<< cla[i].score[0]
                << "\n�p��: "<< cla[i].score[1]
                << "\n�|�p: "<< cla[i].score[2]
                << "\n�g��: "<< cla[i].score[3]
                << "\n�L�n��: "<< cla[i].score[4]
                << "\n������: "<< cla[i].score[5]
                << "\n�W��: "<< cla[i].score[6]
                << endl;
        }
    }
}

void print_all(stu* cla, int clanum) {
    for (int i = 0; i < clanum; i++) {
        cout<< "�Ǹ�: "<< cla[i].num
            << "\t�m�W: "<< cla[i].name
            << "\n�{�]: "<< cla[i].score[0]
            << "\n�p��: "<< cla[i].score[1]
            << "\n�|�p: "<< cla[i].score[2]
            << "\n�g��: "<< cla[i].score[3]
            << "\n�L�n��: "<< cla[i].score[4]
            << "\n������: "<< cla[i].score[5]
            << "\n�W��: "<< cla[i].score[6]
            << endl;
    }
}

void gen_class(stu *cla, int clanum) {
    int i = 0, j = 0;
    while(i < clanum) { //  �üƵ��Ǹ�
        srand(time(NULL));
        cla[i].num = rand() % 1000 + 1033000;
        for (j = 0; j < i; j++) {
            if(cla[j].num == cla[i].num) {
                i--;
                break;
            }
        }
        i++;
    }

    i = 0;
    int chkra = 0;
    while(i < clanum) {
        // �üƨ��W���n�ΡA
        srand(time(NULL));
        int ra = rand() % 10 + 2;
        if (ra == chkra) {
            continue;
        }
        chkra = ra;
        srand(time(NULL));
        int sra = rand() % 26;
        string tmp = "";
        tmp.push_back(char(sra+65));
        for (j = 1; j < ra; j++) {
            srand(time(NULL));
            sra = rand() % 26;
            if (char(sra+97) == tmp[j - 1]) {
                j--;
                continue;
            }
            tmp.push_back(char(sra+97));
        }
        cla[i].name = tmp;

        // �üƵ����Z
        cla[i].score[5] = 0;
        srand(time(NULL));
        cla[i].score[0] = rand() % 101;
        for (j = 1; j < 5; j++) {
            srand(time(NULL));
            cla[i].score[j] = rand() % 101;
            if (cla[i].score[j] == cla[i].score[j - 1]) j--;
        }
        for (j = 0; j < 5; j++) {
            cla[i].score[5] += cla[i].score[j];
        }cla[i].score[5] /= 5;

        i++;
    }

    stu stutmp;
    for (i = 0; i < clanum; i++) {
        for (j = i; j < clanum; j++) {
            if(cla[i].score[5] < cla[j].score[5]) {
                stutmp = cla[i];
                cla[i] = cla[j];
                cla[j] = stutmp;
            }
        }
    }
    for (j = 0; j < clanum; j++) cla[j].score[6] = j + 1;
}

